import java.util.*;
import gnu.io.*;
import java.io.*;
import java.awt.event.*;
import java.awt.*;
//import javax.comm.*;
class SenderGUI extends Frame implements ActionListener{
    SerialPort sp;
	Button submit = new Button("Submit");
	TextField tf1 = new TextField(20);
    
	public SenderGUI(SerialPort x) throws Exception{
		sp = x;
		submit.addActionListener(this);
		Panel p = new Panel();
		p.add(tf1); p.add(submit);
		add(p);
		setSize(900,300);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		try {
				
				DataOutputStream dos = new DataOutputStream(sp.getOutputStream());
				dos.writeUTF(tf1.getText());
			
		} catch (Exception e) {}
	}
    
}

public class Ex4  {
	public static void main(String[] args) throws Exception{
		Enumeration e = CommPortIdentifier.getPortIdentifiers();
		while ( e.hasMoreElements()){
			CommPortIdentifier cp = (CommPortIdentifier) e.nextElement();
			if(cp.getName().equals("COM2")){
				if(cp.getPortType() == CommPortIdentifier.PORT_SERIAL){
					SerialPort sp = (SerialPort) cp.open("myAwesomeApp", 2000);
					System.out.println("connected to COM2");
					sp.setSerialPortParams(9600,SerialPort.DATABITS_8, SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
					SenderGUI a = new SenderGUI(sp);
				}
			}
		}
	}
}