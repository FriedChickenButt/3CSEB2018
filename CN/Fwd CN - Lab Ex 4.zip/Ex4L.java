import java.util.*;
import gnu.io.*;
import java.io.*;
//import javax.comm.*;
class SReader  implements SerialPortEventListener{
    SerialPort sp;
    SReader(SerialPort x) throws Exception{
        sp = x;
        sp.addEventListener(this);
        
    }
    public void serialEvent(SerialPortEvent se) {
		try {
		if(se.getEventType() == SerialPortEvent.DATA_AVAILABLE){
			SerialPort p = (SerialPort)se.getSource();
			DataInputStream dis = new DataInputStream(p.getInputStream());
			System.out.println(dis.readUTF());
		}
	}
	 catch(Exception e) {}
}
}

public class Ex4L  {
	public static void main(String[] args) throws Exception{
		Enumeration e = CommPortIdentifier.getPortIdentifiers();
		while ( e.hasMoreElements()){            
			CommPortIdentifier cp = (CommPortIdentifier) e.nextElement();
			if(cp.getName().equals("COM3")){
				System.out.println("Connected to COM3");
				if(cp.getPortType() == CommPortIdentifier.PORT_SERIAL){
					SerialPort sp = (SerialPort) cp.open("myAwesomeApp", 2000);
					sp.setSerialPortParams(9600,SerialPort.DATABITS_8, SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
					sp.notifyOnDataAvailable(true);
					SReader a = new SReader(sp);
					//sp.close();
				}
			}
		}
	}
}